# 水稻病虫害自动识别系统

#### 介绍
水稻害虫自动识别系统，
<br/>组长&项目经理：朱颖</br>
<br/>产品经理：刘印根</br>
<br/>技术经理：沈锐</br>
<br/>成员：李昕</br>
<br/>成员：徐兆辉</br>
<br/>成员：吐尔克扎提</br>

#### 软件架构与命名规范
admin_login.html 管理员登录界面
index.html 欢迎界面
main.html 首页界面
templates.html 前端模板


所有css的修改请找 css/xadmin.css 
